#ifndef _GL_H
#define _GL_H

#include <GL/glut.h>
#include "point.h"
#include "line.h"
#include "polygon.h"
#include "matrix.h"
#include "utils.h"

#endif
